document.addEventListener("DOMContentLoaded", () => {
  const editor = document.getElementById("editor");
  const wordCount = document.getElementById("wordCount");
  const fontSelector = document.getElementById("fontSelector");
  const themeSelector = document.getElementById("themeSelector");

  // Load saved text
  editor.value = localStorage.getItem("draft") || "Chapter 1: My First Novel\n\nOnce upon a time...";
  updateWordCount();

  editor.addEventListener("input", () => {
    localStorage.setItem("draft", editor.value);
    updateWordCount();
  });

  function updateWordCount() {
    const words = editor.value.trim().split(/\s+/).filter(Boolean).length;
    wordCount.textContent = "Words: " + words;
  }

  fontSelector.addEventListener("change", () => {
    editor.style.fontFamily = fontSelector.value;
  });

  themeSelector.addEventListener("change", () => {
    const theme = themeSelector.value;
    if (theme === "light") {
      document.body.style.background = "linear-gradient(135deg, #f0f0f0, #ffffff)";
      document.body.style.color = "black";
    } else if (theme === "dark") {
      document.body.style.background = "linear-gradient(135deg, #0f0f0f, #1c1c1c)";
      document.body.style.color = "white";
    } else {
      // Auto
      if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
        document.body.style.background = "linear-gradient(135deg, #0f0f0f, #1c1c1c)";
        document.body.style.color = "white";
      } else {
        document.body.style.background = "linear-gradient(135deg, #f0f0f0, #ffffff)";
        document.body.style.color = "black";
      }
    }
  });

  document.getElementById("exportTxt").addEventListener("click", () => {
    downloadFile("draft.txt", editor.value);
  });

  document.getElementById("exportDocx").addEventListener("click", () => {
    downloadFile("draft.docx", editor.value);
  });

  function downloadFile(filename, text) {
    const blob = new Blob([text], { type: "text/plain" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    link.click();
  }
});
